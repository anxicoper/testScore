
 function clicker() {
    $("p").hide();
}

  $(document).ready(function(){
    $("#myButton").click(function(){
        clicker();
    });
});
